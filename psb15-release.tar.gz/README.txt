This release makes available extracted pathways, sample annotation, and trigger rules used by the rule-based system in the following paper:

Distant Supervision for Cancer Pathway Extraction from Text
Hoifung Poon, Kristina Toutanova, Chris Quirk
In Proceedings of the Pacific Symposium on Biocomputing, 2015.

pathway-extraction.txt: Extracted pathways using distant supervision from PID. The columns are PMID, Sentence, Theme, Cause, Regulation Type, Sentence. The sentence is marked up with theme in <> and cause in [].

sample300-annotated.txt: Sample extractions with manual annotation. Below are annotation labels and their statistics.
Y	75	correct
P       56	protein error
S       27	incorrect sign
N       96	not regulation
D       46	incorrect causal direction

trigger-rules.txt: Trigger rules used in the rule-based system.

Contact info: hoifung@microsoft.com
Date: 2014.10.1
